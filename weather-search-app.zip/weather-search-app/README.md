# Weather Search App

A Pen created on CodePen.io. Original URL: [https://codepen.io/prud3266/pen/abGPVBJ](https://codepen.io/prud3266/pen/abGPVBJ).

