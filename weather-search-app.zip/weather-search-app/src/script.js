const cityName = document.getElementById('cityname');
const Temp = document.getElementById('temp');
const Humidity = document.getElementById('humidity');
const maxTemp = document.getElementById('max_temp');
const minTemp = document.getElementById('min_temp');
const searchBtn = document.getElementById('search')

const options = {
	method: 'GET',
	headers: {
		'X-RapidAPI-Key': 'cba7954da9msh471cabcfe861514p1362f1jsn48155097017b',
		'X-RapidAPI-Host': 'weather-by-api-ninjas.p.rapidapi.com'
	}
};



const getWeather = async (city) => {
  try{
    let url = `https://weather-by-api-ninjas.p.rapidapi.com/v1/weather?city=${city}`
    const response = await fetch(url, options);
    const data = await response.json();
    Temp.innerText = `Temperature: ${data.temp}`;
    Humidity.innerText = `Humidity: ${data.humidity}` ;
    minTemp.innerText = `Minimum Temperature: ${data.min_temp}`;
    maxTemp.innerText = `Maximum Temperature: ${data.max_temp}`;
  }catch(e){
    console.log(e);
  }
}

const getCity = () => {
  let city = cityName.value
  console.log(city)
  getWeather(city)
}





// <p id = 'temp'></p>
// <p id = 'temp'></p>
// <p id = 'temp'></p>
// <p id = 'temp'></p>

// <p id = 'temp'></p>
// <p id = 'humidity'></p>
// <p id = 'max_temp'></p>
// <p id = 'min_temp'></p>




// const options = {
// 	method: 'GET',
// 	headers: {
// 		'X-RapidAPI-Key': 'cba7954da9msh471cabcfe861514p1362f1jsn48155097017b',
// 		'X-RapidAPI-Host': 'yahoo-weather5.p.rapidapi.com'
// 	}
// };

// const getWeather = async (city) => {
//   try{
//     let url = `https://yahoo-weather5.p.rapidapi.com/weather?location=${city}&format=json&u=f`
//     const response = await fetch(url, options);
//     const data = await response.json();
//     console.log(data)
//   }catch(e){
//     console.log(e);
//   }
// }

// const getCity = () => {
//   let city = cityName.value
//   console.log(city)
//   getWeather(city)
// }
